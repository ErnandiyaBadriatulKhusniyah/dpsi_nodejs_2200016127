const express = require('express');
const router = express.Router();
const User = require('../models/user');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

// Rute pendaftaran
router.post('/register', async (req, res, next) => {
  try {
    const { username, password, role } = req.body;

    // Simpan pengguna baru dengan password yang sudah di-hash
    const newUser = await User.create({ username, password, role });
    res.status(201).json({ message: 'User registered successfully' });
  } catch (err) {
    next(err);
  }
});

// Rute login
router.post('/login', async (req, res, next) => {
  try {
    const { username, password } = req.body;

    // Cari pengguna berdasarkan username
    const user = await User.findOne({ where: { username } });

    // Jika pengguna tidak ditemukan, kirim respons 401
    if (!user) {
      return res.status(401).json({ message: 'Invalid Username' });
    }

    // Bandingkan password yang dikirimkan dengan password yang disimpan dalam database
    const isMatch = await bcrypt.compare(password, user.password);

    // Jika password tidak cocok, kirim respons 401
    if (!isMatch) {
      return res.status(401).json({ message: 'Invalid Password' });
    }

    // Buat token JWT dengan informasi yang sesuai
    const token = jwt.sign({ id: user.id, role: user.role }, 'your_jwt_secret', { expiresIn: '1h' });

    // Kirim token JWT sebagai respons
    res.json({ token });
  } catch (err) {
    // Tangani kesalahan dengan middleware error handler
    next(err);
  }
});

module.exports = router;
